package kg.beeline.microservice.customer.exception;

public class BalanceReplenishmentUnProcessException extends RuntimeException {
    public BalanceReplenishmentUnProcessException() {
        super("message");
    }
}

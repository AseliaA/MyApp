package kg.beeline.microservice.customer.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
@Setter
public class BalanceReplenishmentRequestDto {
    @NotNull
    private Long customerId;
    @NotNull
    private BigDecimal amount;
}

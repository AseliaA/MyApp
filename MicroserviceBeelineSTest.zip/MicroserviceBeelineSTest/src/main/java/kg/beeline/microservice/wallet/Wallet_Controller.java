package kg.beeline.microservice.wallet;

import org.springframework.web.bind.annotation.*;

@RestController
public class Wallet_Controller {

    //Не стала создавать базу данных
    Wallet_Model wallet_model1 = new Wallet_Model("Aselia", "Azimkanova", 1000);



    //запрос на получения суммы денег в кошельке
    @RequestMapping(value = "/{name}/{surname}", method = RequestMethod.GET)
    public long myValue(@PathVariable String name, @PathVariable String surname) throws Exception {
        if (name.equals(wallet_model1.getName()) & surname.equals(wallet_model1.getSurname())) {
            return wallet_model1.getValue();
        } else throw new Exception("Вы не правильно ввели Имя или Фамилию");
    }

    //метод который автомотический будет минусовать суммы которые перевели на баланс из кошелька
    //пока не работает
//    @RequestMapping(value ="", method = RequestMethod.GET)
//    public long howMuchLeft(@PathVariable int howMuch){
//        wallet_model1.minusValue(howMuch);
//        return wallet_model1.getValue();
//    }
}

package kg.beeline.microservice.customer.model;

public class BalanceModel {
}
